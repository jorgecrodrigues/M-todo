<?php

/**
 * Módulo de um número.
 *
 * @param  int $x
 * @return float|int
 */
function mod($x)
{
    if ($x < 0) return -1 * $x;
    return $x;
}

/**
 * Classe para fazer a validação e a conversão de uma string para
 * uma expressão matemática válida para a linguagem.
 *
 * Crédito:
 * EvalMath - PHP Class to safely evaluate math expressions
 * Copyright (C) 2005 Miles Kaufmann <http://www.twmagic.com/>
 */
include_once('evalmath.class.php');
$Math = new EvalMath;

// Verifica pelas entradas necessárias.
if ($_POST && isset($_POST['mm']) && isset($_POST['error'])) {
    //
    $mm = $_POST['mm'];
    //
    $error = $Math->evaluate("1/" . $_POST['error']);
    //
    $explode = explode(';', $mm);
    foreach ($explode as $value) {
        $A[] = explode(',', $value);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Métodos computacionais</title>
    <!-- Bulma 0.6.1 -->
    <link rel="stylesheet" href="bulma-0.6.1/css/bulma.css"/>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css"/>
    <script src="jquery-3.2.1/jquery-3.2.1.min.js"></script>
</head>
<body>
<?php include_once "nav.php"; ?>
<br/>
<br/>
<div class="container">
    <div class="columns">
        <div class="column is-4">
            <h2 class="is-size-2">Eliminação de Gauss com Pivô Parcial</h2>
            <form method="post">
                <div class="field">
                    <label class="label">Erro:</label>
                    <div class="control has-icons-left has-icons-right">
                        <input class="input is-danger" type="text" name="error" value="10^2" placeholder="Ex: 10^2"
                               required>
                        <span class="icon is-small is-left"><i class="fa fa-long-arrow-right"></i></span>
                        <span class="icon is-small is-right"></span>
                    </div>
                    <p class="help is-danger">Padrão 10²</p>
                </div>
                <div class="field">
                    <label class="label">A matriz IxI</label>
                    <div class="control">
                        <textarea class="textarea" placeholder="1,3,4,3;
4,7,8,6;
1,-4,5,4"
                                  name="mm"></textarea>
                    </div>
                </div>
                <div class="field is-grouped">
                    <div class="control">
                        <button type="submit" class="button is-primary">Calcular</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="column">
            <div class="columns">
                <div class="column has-text-centered">
                    <?php $ci = count($A) ?>
                    <?php $max = 0 ?>
                    <?php for ($ii = 0; $ii < $ci; $ii++): ?>
                        <?php $sum = 0 ?>
                        <?php $cj = count($A[$ii]) ?>
                        <div class="columns">
                            <?php for ($jj = 0; $jj < $cj; $jj++): ?>
                                <?php if ($ii != $jj): ?>
                                    <?php $sum = $sum + mod($A[$ii][$jj]) ?>
                                <?php endif; ?>
                                <?php $sum = $sum + mod($A[$ii][$ii]) ?>
                                <?php if ($max < $sum): ?>
                                    <?php $max = $sum ?>
                                <?php endif; ?>
                                <?php $count = 0 ?>
                                <!-- Gauss - Jacobi -->
                                <?php while ($x): ?>
                                    <?php $count = $count + 1 ?>
                                    <!-- Numerador -->
                                    <?php $nn = 0; ?>
                                    <!-- Denominador -->
                                    <?php $dd = 0 ?>

                                    <?php for ($i = 0; $i < $ci; $i++): ?>
                                        <?php $yi = 0; ?>
                                        <?php for ($j = 0; $j < $cj; $j++): ?>
                                        <?php endfor; ?>
                                    <?php endfor; ?>

                                <?php endwhile; ?>
                                <div class="column">
                                    <?php echo $A[$ii][$jj] . " [" . $ii . "," . $jj . "]" ?>
                                </div>
                            <?php endfor; ?>
                        </div>
                    <?php endfor; ?>

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
