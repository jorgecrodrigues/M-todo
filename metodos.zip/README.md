# Métodos
Algoritmos de métodos computacionais
